/*
Array.prototype.contains = function(obj) {
    var i = this.length;
    while (i--) {
        if (this[i] === obj) {
            return true;
        }
    }
    return false;
}
*/
String.prototype.startsWith = function (str){
	return this.slice(0, str.length) == str;
}

String.prototype.endsWith = function (str){
	return this.slice(-str.length) == str;
}

String.format = function() {
  var s = arguments[0];
  for (var i = 0; i < arguments.length - 1; i++) {       
    var reg = new RegExp("\\{" + i + "\\}", "gm");             
    s = s.replace(reg, arguments[i + 1]);
  }
  return s;
}

String.prototype.removeBreakLine = function() { 
	return this.replace(/(\r\n|\n|\r)/gm," ");
}