/***
 * file: board.js
 * version: 0.6.0
 * author: https://github.com/quasto
  ***/

/*** import ***/
var	net = require('net'),
	layouts = require('./utils/layout'),layouts2 = require('./utils/layout2'),
	utils = require('./utils/utils'),
	path = require('path');
	EventEmitter = require('events').EventEmitter,
	exec = require('child_process').exec,
	u = require('underscore'),
	async = require('async');
	
var	pinReg = {},		//list for storing the mode of every used pin of the board
	logger,				//winston logger
	layout,
	layout2,	
	event = new EventEmitter();
	
/*** constants ***/	
var	CHECK_MSG = {	PIN_UNDEFINED : 	"The specified pin is undefined!",
					PIN_NOT_DIGITAL: 	"The specified pin [{0}] is not a Digital pin",
					PIN_NOT_ANALOG: 	"The specified pin [{0}] is not an Analog pin",
					PIN_NOT_VIRTUAL: 	"The specified pin [{0}] is not a Virtual pin",
					PIN_NOT_LAYOUT:		"The specified pin [{0}] is not defined in the board layout!",
					PIN_NOT_DEFINED:	"The specified pin [{0}] is not already defined! You must first, call pinMode!",
					MODE_NOT_VALID: 	"The specified mode [{0}] for pin [{1}] is not valid.",
					MODE_UNDEFINED : 	"The specified mode for pin [{0}] is undefined!"
				},
	GPIO_D = path.join('sys','class','gpio'),
	GPIO_A = path.join('sys','class','mcuio_adc');
	GPIO_A_ENABLE = path.join('sys','devices','mcuio_0:0.0/adc');
				
module.exports = Board;

/*** constructor ***/
function Board(options) {
	//load the default options from config file
	var file_options = require('./config');
	
	//user can specifies overwrite options in the costructor
	this._options = utils.mergeRecursive(file_options, options);
	//file_options.merge(options);
	//this._options = file_options;

	this._bridge = {
			bridge : 'bridge-firmata.py',
			stop : 'bridge-stop',
			bridge_exe : path.join(__dirname,'ext','bridge-firmata.py'),
			stop_exe : path.join(__dirname,'ext','bridge-stop'),
			loglevel : 'info', 		//error, warn, info, debug //this._options.logger.level (prima di mettere questo, devo togliere molti log dal bridge, altrimenti in debug impazzisce per i troppi log //
			loghandler : this._options.logger.handler, 	//file, console, all (file + console)
			layout : this._options.layout,				//arduino_yun, linino_one
			layoutfile : path.join(__dirname,'utils','layout.json'),	//layout file
			resolution : this._options.bridge.resolution,
			serial: this._options.bridge.serial,
			sampling : this._options.bridge.sampling			
	};
	
	layout = layouts[this._options.layout];
	layout2 = layouts2[this._options.layout];
	//setting the logger;
	logger = utils.getLogger(this._options.logger);
	logger.debug(file_options);
	
	/*** Board attributes ***/
	Board.prototype.pin = layout;
	Board.prototype.LOW = utils.LOW;
	Board.prototype.HIGH = utils.HIGH;
	Board.prototype.MODES = utils.MODES; 
	Board.prototype.logger = logger;
	
	event.setMaxListeners(0);
}

/*** PUBLIC ***/  
/*** Board functions ***/
Board.prototype.connect = function(callback){
	logger.info("Connecting to the Board "+ this._options.layout +"...");
	var that = this;

	async.series([
		function(cb){
		logger.debug("starting export analog adcs...");//export analog pins				
			gpio_a_export(function(err, status){
				if(err){
					logger.error("analog adc export error" + err.message);
					cb(new Error("analog adc export error" + err.message));
				}
				else{
					logger.debug("analog adcs export " + status);
					cb(null,"analog adc export " + status);
				}
			});
		},
		function(cb){
			logger.debug("starting export digital adcs...");//export digital pins
			setTimeout(function(){
				var digitalpins = u.filter(
					layout2, 
					function(pin){return pin.TYPE == 'digital';}
				);
				
				async.each( digitalpins,
					function(pin,clb){
						gpio_d_export(pin, function(err, status){
							if(err){
								logger.error("digital gpio " + pin.GPIO + " export error" + err.message);
								clb("digital gpio " + pin.GPIO + " export error" + err.message);
							}else{
								logger.debug("digital gpio " + pin.GPIO + " export " + status);
								//pin.DIRECTION = 'in';
								//pinReg[pin.DEF] = 'input';
								clb(null);
							}
						});
					},
					function(err){
						if(err){ cb(new Error(err));}
						else{ cb(null,"digital gpios export ok.") };
					}
				);
			},500);
		},
		function(cb){logger.debug("start polling...");
			setTimeout(function(){
			setInterval(function(){
					u.each(layout2,function(pin, index, list){
						if(pin.hasOwnProperty('VALUE')){
							gpio_read_value( pin , function(err,val){ 
								//nei valori analogici si deve impostare la risoluzione
								//pin.VALUE => valore precedente
								//val => valore attuale
								if(pin.TYPE.toLowerCase() == 'analog'){
									if(val <= (pin.VALUE - that._bridge.resolution)
									|| val >= (pin.VALUE + that._bridge.resolution)){
										logger.debug(pin.MAP + " changed value: " + pin.VALUE + " > "+ val);
										pin.VALUE = val;
										event.emit('read-back-'+pin.MAP, {value:val} );
									}
								}else{
									if(pin.VALUE != val){
										logger.debug(pin.MAP + " changed value: " + pin.VALUE + " > "+ val);
										pin.VALUE = val;
										event.emit('read-back-'+pin.MAP, {value:val} );
									}
								}
							});
						}		
					});
			},that._bridge.sampling);
			cb(null,"polling ok");
			},500);
		}],
		function(err, results){
			setTimeout(function(){
			if(err){
				logger.error("errore nella connect"+err);
				logger.error("+Board Connection Error ["+err+"]");
			}
			else{
				logger.debug(results);
				logger.info("Board Connection Success");
				//torno all'app
				callback();
			}
			},500);
		}
	);
}

/*
Board.prototype.connect = function(callback){
	var that = this;
	exec("sh " + this._bridge.stop_exe + " " + this._bridge.bridge, function (error, stdout, stderr) {
		
		proc  = spawn('python', [that._bridge.bridge_exe, "-log", that._bridge.loglevel, that._bridge.loghandler, "-layout", that._bridge.layout, that._bridge.layoutfile, "-resolution", that._bridge.resolution, "-serial",that._bridge.serial.port, that._bridge.serial.baudrate, "-sampling", that._bridge.sampling  ]);
		
		if(that._bridge.loglevel == 'debug' ){
			proc.stdout.on('data', function (data) {
			  logger.debug('BRIDGE STDOUT: ' + data);
			});
			proc.stderr.on('data', function (data) {
			  logger.debug('BRIDGE STDERR: ' + data);
			});
			proc.on('close', function (code) {
			  logger.debug('BRIDGE PROCESS EXITED WITH CODE: ' + code);
			});
		}
		
		logger.info("Connecting to the Board "+ that._options.layout +"...");
		var waitForSocket = require('socket-retry-connect').waitForSocket;
		waitForSocket({port:PORT, host:SERVER, tries: BRIDGE_CONN_RETRIES}, function(err, sck) {
			if(!err){
				socket = sck;
				socket.setEncoding(ENCODING);
				//sending event from buffer
				setInterval(function(){
					sendWriteRequest();
				},BUFFER_SPEED);
				
				//send user a signal by blinking for 1 seconds the led
				that.blink(100, 2500, 'D13');
				logger.info("Board Connection Success");
				callback(true);			
				socket.on('data', function(data) {
					//message from server
					if ( data.search('}{') == -1){
						eventEmit(data);
					}
					else{
						data=data.replace(/}{/g,'}~{').split('~');
						data.forEach(function(cmditem) {
							eventEmit(cmditem);
						});
					}
				});
				socket.on('error', function (e) {
					logger.error("+Board Connection Error ["+e.code+"]");
					logger.error(e);
					exec("sh " + that._bridge.stop_exe + " " + that._bridge.bridge, function (error, stdout, stderr) {
						process.exit(1);
					});
				});		
			}
			else{
				logger.error("-Board Connection Error: Maximum connection retries exceeded ["+BRIDGE_CONN_RETRIES+"]");
				exec("sh " + that._bridge.stop_exe + " " + that._bridge.bridge, function (error, stdout, stderr) {
					process.exit(1);
				});		
			}
		}); 
	});
}
*/
Board.prototype.blink = function(){
	var that = this;
	// retrieve arguments as array
    var args = [];
    var delay, duration;
	for (var i = 0; i < arguments.length; i++) {
        args.push(arguments[i]);
    }
	var delay, led, duration;
	//check loglevel parameters
	if (args.length > 0) delay = args.shift(); else throw new Error("specify delay parameter.");
    if (args.length > 0) duration = args.shift(); else duration = 0;
	if (args.length > 0) led = args.shift(); else led = layout.digital.D13;

	if ( !isNaN(delay) ){
		if( typeof(duration) != 'undefined'  && !isNaN(duration) ){
			that.pinMode(led, utils.MODES.OUTPUT);
			var t = utils.LOW,
			interval = setInterval( function(){
				that.digitalWrite(led, t );
				t = t == utils.LOW ? utils.HIGH : utils.LOW;
			}, delay);
			
			if(duration > 0 ){
				setTimeout(function(){
					clearInterval(interval);
					that.digitalWrite(led, utils.LOW);
				},duration);
			}
		}
		else{
			throw new Error("duration is not a number."); 
		}
	}else{
		throw new Error("delay is not a number."); 
	}
	
}
Board.prototype.pinMode = function(pin, mode) {
	try {
		checkPinMode(pin,mode,function(err){
			if(err){
				throw err;
			}
			else{
				//switch
				switch(mode.toLowerCase()) {
					case 'input':
						gpio_set_direction(layout2[pin],'in',function(err, code){
							if(!err){ 
								layout2[pin].DIRECTION = 'in'; 
								//layout2[pin].VALUE = 
								gpio_read_value(layout2[pin],function(err,valore){
										layout2[pin].VALUE = valore;
								});
								pinReg[pin] = mode;
								logger.debug("pin " + pin + " is set to " + mode + " mode.");
							}
							else{
								logger.error(err.message);
								throw err;
							}
						});
						break;
					case 'output':
						gpio_set_direction(layout2[pin],'out',function(err, code){
							if(!err){ 
								layout2[pin].DIRECTION = 'out'; 
								//layout2[pin].VALUE = 
								//gpio_read_value(layout2[pin],function(err,valore){
								//		layout2[pin].VALUE = valore;
								//});
								pinReg[pin] = mode;
								logger.debug("pin " + pin + " is set to " + mode + " mode.");								
							}
							else{
								logger.error(err.message);
								throw err;
							}
						});
						break;
					case 'pwm':
						//TODO
						break;
					case 'servo':
						//TODO
						break;
				}
			}
		});
	}
	catch(err){
		logger.error("BOARD PIN MODE ERROR - " + err.message);
		exec("sh " + this._bridge.stop_exe + " " + this._bridge.bridge, function (error, stdout, stderr) {
			process.exit(1);
		});		
	}
}
Board.prototype.digitalWrite = function(pin, value) {
    try {
		process.nextTick(function(){
			checkDigitalWrite(pin, function(err){
				if(err){
					logger.error(err.message);
				}else{
					//var cmd = JSON.stringify({ command:[ {cmd: 'write', pin: pin, value: value } ]});
					//pushWriteRequest(cmd);
					gpio_write_value(layout2[pin], value );
				}
			});		
		});
	}
	catch(err){
		logger.error("BOARD DIGITAL WRITE ERROR - " + err.message);
	}
}
Board.prototype.digitalRead = function(pin, callback) {
	try {
		process.nextTick(function(){
			checkDigitalRead(pin,function(err){
				if(err){
					logger.error(err.message);
				}
				else{
					//var cmd = JSON.stringify({command:[{cmd: 'read', pin: pin}]});
					//socket.write(cmd,ENCODING,readback(pin, callback)); //when connection is ok, emit the request
					gpio_read_value(layout2[pin],function(err,val){
						layout2[pin].VALUE = val;
						readback(layout2[pin].MAP, callback);
					});
				}
			});
		});
	}
	catch(err){
		logger.error("BOARD DIGITAL READ ERROR - " + err.message);
	}  
}
Board.prototype.analogWrite = function(pin, value) {
    try {
		process.nextTick(function(){
			checkAnalogWrite(pin, function(err){
				if(err){
					logger.error(err.message);
				}else{
					if(value>=1024) value = 1024;
					if(value<=0) value = 0;
					value = Math.round(value/1024 * 10000) / 10000; //trunc 4 decimal digits
					var cmd = JSON.stringify({ command:[ {cmd: 'write', pin: pin, value: value } ]});
					//socket.write(cmd,ENCODING); //when connection is ok, emit the request
					pushWriteRequest(cmd);
				}
			});
		});
	}
	catch(err){
		logger.error("BOARD ANALOG WRITE ERROR - " + err.message);
	}
}
Board.prototype.analogRead = function(pin, callback) {
    try {
		process.nextTick(function(){
			checkAnalogRead(pin,function(err){
				if(err){
					logger.error(err.message);
				}
				else{
					//var cmd = JSON.stringify({command:[{cmd: 'read', pin: pin}]});
					//socket.write(cmd,'utf8',readback(pin, callback)); //when connection is ok, emit the request
					gpio_read_value(layout2[pin],function(err,val){
						layout2[pin].VALUE = val;
						readback(layout2[pin].MAP, callback);
					});
				}
			});
		});
	}
	catch(err){
		logger.error("BOARD ANALOG READ ERROR - " + err.message);
	}
}
Board.prototype.servoWrite = function(pin, angle){
    try {
		process.nextTick(function(){
			checkServoWrite(pin,function(err){
				if(err){
					logger.error(err.message);
				}
				else{
					var cmd = JSON.stringify({command:[{cmd: 'write', pin: pin, value: angle}]});
					//socket.write(cmd,'utf8'); //when connection is ok, emit the request
					pushWriteRequest(cmd);
				}
			});
		});
	}
	catch(err){
		logger.error("BOARD SERVO WRITE ERROR - " + err.message);
	}
}
/*** Virtual Board functions ***/ 
Board.prototype.virtualWrite = function(virtualpin, value){
	try {
		checkVirtualWrite(pin,function(err){
			if(err){
				logger.error(err.message);
			}
			else{
				var cmd = JSON.stringify({ command:[ {cmd: 'virtualwrite', pin: virtualpin, value: value } ]});
				pushWriteRequest(cmd);
			}
		});
				
	}
	catch(err){
		logger.error(err);
	}
}
Board.prototype.virtualRead = function(virtualpin, calback){
	try {
		checkVirtualRead(pin,function(err){
			if(err){
				logger.error(err.message);
			}
			else{
				var cmd = JSON.stringify({command:[{cmd: 'vread', pin: virtualpin}]});
				socket.write(cmd,ENCODING,readback(pin, callback)); //when connection is ok, emit the request
			}
		});
	}
	catch(err){
		logger.error(err.message);
	} 
}

/*** PRIVATE ***/	
/*** Lib functions ***/
function eventEmit(data){
	if(	typeof(data) != 'undefined'){
		try{
			datajson = JSON.parse(data);
			if( typeof(datajson.cmd) != 'undefined' && 
				datajson.cmd == 'read-back'){
				event.emit('read-back-'+datajson.pin, data);
			}
		}
		catch(err){
			logger.error("BOARD EVENT EMIT ERROR - " + err.message);
		}
	}
}
function readback(mpin, callback){
	//if(typeof(socket) != 'undefined' ){
		event.on('read-back-'+mpin,function(data){
			//callback(JSON.parse(data));
			callback(data);
		});
	//}
}




/*** GPIO functions ***/
function gpio_d_export(pin, cb){
	var cmd_export;
	cmd_export = exec('echo '+pin.GPIO+' > /sys/class/gpio/export',function (error, stdout, stderr) {
		if(error){
			if(stderr.toLowerCase().indexOf('device or resource busy') > -1){
				cb(null,'ok');
			}else{ 
				cb(new Error(stderr));
			}
		}
		else{
			cb(null,'ok');
		}	
	});
}
function gpio_a_export(cb){
	var cmd_enable;
	cmd_enable = exec('echo 1 > /sys/devices/mcuio/0:0.0/adc/enable',function (error, stdout, stderr) {
		if(error){
			cb(new Error(stderr));
		}
		else{
			cb(null,'ok');
		}
		
		
	});
}
function gpio_set_direction(pin, direction, cb){
	var cmd_direction;
		//TODO: check if exist
		//TODO: join path and use const path
	cmd_direction = exec('echo '+direction+' > /sys/class/gpio/'+ pin.MAP+ '/direction',function (error, stdout, stderr) {
		if(error){
			cb(new Error(stderr));
		}
		else{
			cb(null,'ok');
		}
	});
}
function gpio_read_value(pin, cb){
	var cmd_value
	if(pin.TYPE == 'analog'){
		cmd_value = exec('cat /sys/class/mcuio_adc/'+pin.MAP+'/value', function (error, stdout, stderr) {
			if (error) {
			  console.log('value exec error: ' + error);
			  cb(new Error(stderr));
			}else{
				//pin.VALUE = stdout.removeBreakLine();
				//cb(null,pin.VALUE);
				cb(null,parseInt(stdout));
			}
		});	
	}else{
		cmd_value = exec('cat /sys/class/gpio/'+pin.MAP+'/value', function (error, stdout, stderr) {
			if (error) {
			  console.log('value exec error: ' + error);
			  cb(new Error(stderr));
			}else{
				//pin.VALUE = stdout.removeBreakLine();
				//cb(null, pin.VALUE);
				cb(null,parseInt(stdout));
			}
		});
}
	
}
function gpio_write_value(pin, value){
		
	var cmd_value
	if(pin.TYPE == 'analog'){
		cmd_value = exec('echo '+ value +' > /sys/class/mcuio_adc/'+pin.MAP+'/value', function (error, stdout, stderr) {
			if (error) {
			  console.log('value exec error: ' + error);
			  //cb(new Error(stderr));
			}else{
				//probabilmente lo lascio disabilitato perchè sarà o la lettura o il ciclo di polling ad aggiornare il registro
				//pin.VALUE = value;
				//cb(null,pin.VALUE);
			}
		});	
	}else{
		cmd_value = exec('echo '+ value +' > /sys/class/gpio/'+pin.MAP+'/value', function (error, stdout, stderr) {
			if (error) {
			  console.log('value exec error: ' + error);
			  //cb(new Error(stderr));
			}else{
				//pin.VALUE = value;
				//cb(null, pin.VALUE);
			}
		});
	}
}

/*** Check functions ***/
function checkPinMode(pinnumber,mode, callback){
	try{	
		if( typeof(pinnumber) == 'undefined'){
			callback( new Error(CHECK_MSG.PIN_UNDEFINED) );return false;
		}
		if( !pinnumber.toLowerCase().startsWith('d')){ 
			callback( new Error(String.format(CHECK_MSG.PIN_NOT_DIGITAL,pinnumber)) );return false
		}
		if( !utils.contains(layout.digital, pinnumber) ){
			callback( new Error(String.format(CHECK_MSG.PIN_NOT_LAYOUT,pinnumber)) );return false;
		}
		if( typeof(mode) == 'undefined'){
			callback(new Error(String.format(CHECK_MSG.MODE_UNDEFINED,pinnumber)) );return false;
		}
		if(	mode.toLowerCase() != utils.MODES.OUTPUT.toLowerCase()	&& 
			mode.toLowerCase() != utils.MODES.INPUT.toLowerCase() 	&&
			mode.toLowerCase() != utils.MODES.PWM.toLowerCase() 	&& 
			mode.toLowerCase() != utils.MODES.SERVO.toLowerCase()	){
			callback(new Error(String.format(CHECK_MSG.MODE_NOT_VALID, mode, pinnumber) + " Allowed modes are: "+ utils.MODES.OUTPUT +", "+ utils.MODES.INPUT + ", "+ utils.MODES.PWM + ", "+ utils.MODES.SERVO ));return false;
		}
		
		callback(null);
		return true;
	}
	catch(err){
		callback( new Error('Check Pin Mode '+ err.message) );
		return false
	}
}
function checkDigitalWrite(pinnumber, callback){	
	try{
		if( typeof(pinnumber) == 'undefined'){
			callback( new Error( CHECK_MSG.PIN_UNDEFINED ) );return false;
		}
		if( !pinnumber.toLowerCase().startsWith('d')){ 
			callback( new Error( String.format(CHECK_MSG.PIN_NOT_DIGITAL, pinnumber) ) );return false;
		}
		if(typeof(pinReg[pinnumber]) == 'undefined'){
			callback( new Error( String.format(CHECK_MSG.PIN_NOT_DEFINED, pinnumber) ) );return false;
		}
		if( !utils.contains(layout.digital, pinnumber) ){
			callback( new Error(String.format(CHECK_MSG.PIN_NOT_LAYOUT, pinnumber) ) );return false;
		}
		if(pinReg[pinnumber].toLowerCase() != utils.MODES.OUTPUT.toLowerCase() ){
			callback(new Error( String.format(CHECK_MSG.MODE_NOT_VALID, pinReg[pinnumber].toLowerCase(), pinnumber) + " Allowed modes are: "+ utils.MODES.OUTPUT));return false;
		}
		
		callback(null);
		return true;
	}
	catch(err){
		callback( new Error('Check Digital Write '+ err.message) );
		return false
	}
}
function checkDigitalRead(pinnumber, callback){
	try{
		if( typeof(pinnumber) == 'undefined'){
			callback( new Error( CHECK_MSG.PIN_UNDEFINED ) );return false;
		}
		if( !pinnumber.toLowerCase().startsWith('d')){ 
			callback( new Error( String.format(CHECK_MSG.PIN_NOT_DIGITAL, pinnumber) ) );return false;
		}
		if(typeof(pinReg[pinnumber]) == 'undefined'){
			callback( new Error( String.format(CHECK_MSG.PIN_NOT_DEFINED, pinnumber) ) );return false;
		}
		if( !utils.contains(layout.digital, pinnumber) ){
			callback( new Error(String.format(CHECK_MSG.PIN_NOT_LAYOUT, pinnumber) ) );return false;
		}
		if(	pinReg[pinnumber].toLowerCase() != utils.MODES.OUTPUT.toLowerCase()	&& 
			pinReg[pinnumber].toLowerCase() != utils.MODES.INPUT.toLowerCase() 	&&
			pinReg[pinnumber].toLowerCase() != utils.MODES.PWM.toLowerCase() ){
			callback(new Error(String.format(CHECK_MSG.MODE_NOT_VALID, pinReg[pinnumber].toLowerCase(), pinnumber) + " Allowed modes are: "+ utils.MODES.OUTPUT +", "+ utils.MODES.INPUT + ", "+ utils.MODES.PWM ));return false;
		}
		
		callback(null);
		return true;
	}
	catch(err){
		callback( new Error('Check Digital Read '+ err.message) );
		return false
	}
}
function checkAnalogWrite(pinnumber,callback){	
	try{
		if( typeof(pinnumber) == 'undefined'){
			callback( new Error( CHECK_MSG.PIN_UNDEFINED ) );return false;
		}
		if( !pinnumber.toLowerCase().startsWith('d')){ 
			callback( new Error( String.format(CHECK_MSG.PIN_NOT_DIGITAL, pinnumber) ) );return false;
		}
		if(typeof(pinReg[pinnumber]) == 'undefined'){
			callback( new Error( String.format(CHECK_MSG.PIN_NOT_DEFINED, pinnumber) ) );return false;
		}
		if( !utils.contains(layout.pwm, pinnumber) ){
			callback( new Error(String.format(CHECK_MSG.PIN_NOT_LAYOUT, pinnumber) ) );return false;
		}
		if(pinReg[pinnumber].toLowerCase() != utils.MODES.PWM.toLowerCase() ){
			callback(new Error( String.format(CHECK_MSG.MODE_NOT_VALID, pinReg[pinnumber].toLowerCase(), pinnumber) + " Allowed modes are: "+ utils.MODES.PWM));return false;
		}
		
		callback(null);
		return true;
	}
	catch(err){
		callback( new Error('Check Analog Write '+ err.message) );
		return false
	}
}
function checkAnalogRead(pinnumber,callback){
	try{
		if( typeof(pinnumber) == 'undefined'){
			callback( new Error( CHECK_MSG.PIN_UNDEFINED ) );return false;
		}
		if( !pinnumber.toLowerCase().startsWith('a')){ 
			callback( new Error( String.format( CHECK_MSG.PIN_NOT_ANALOG, pinnumber ) ) );return false;
		}
		/* analog pin are in input mode (default), non verifico il pin mode
		if(typeof(pinReg[pinnumber]) == 'undefined'){
			callback( new Error( String.format(CHECK_MSG.PIN_NOT_DEFINED, pinnumber) ) );return false;
		}
		*/
		if( !utils.contains(layout.analog, pinnumber) ){
			callback( new Error(String.format(CHECK_MSG.PIN_NOT_LAYOUT, pinnumber) ) );return false;
		}
		callback(null);
		return true;
	}
	catch(err){
		callback( new Error('Check Analog Read '+ err.message) );
		return false
	}
}
function checkServoWrite(pinnumber,callback){	
	try{
		if( typeof(pinnumber) == 'undefined'){
			callback( new Error( CHECK_MSG.PIN_UNDEFINED ) );return false;
		}
		if( !pinnumber.toLowerCase().startsWith('d')){ 
			callback( new Error( String.format( CHECK_MSG.PIN_NOT_DIGITAL, pinnumber ) ) );return false;
		}
		if(typeof(pinReg[pinnumber]) == 'undefined'){
			callback( new Error( String.format(CHECK_MSG.PIN_NOT_DEFINED, pinnumber) ) );return false;
		}
		if( !utils.contains(layout.servo, pinnumber) ){
			callback( new Error(String.format(CHECK_MSG.PIN_NOT_LAYOUT, pinnumber) ) );return false;
		}
		if(pinReg[pinnumber].toLowerCase() != utils.MODES.SERVO.toLowerCase() ){
			callback(new Error( String.format(CHECK_MSG.MODE_NOT_VALID, pinReg[pinnumber].toLowerCase(), pinnumber) + " Allowed modes are: "+ utils.MODES.SERVO));return false;
		}
		
		callback(null);
		return true;
	}
	catch(err){
		callback( new Error('Check Servo Write '+ err.message) );
		return false
	}
}
function checkVirtualWrite(pinnumber, callback){	
	try{
		if( typeof(pinnumber) == 'undefined'){
			callback( new Error( CHECK_MSG.PIN_UNDEFINED ) );return false;
		}
		if( !pinnumber.toLowerCase().startsWith('v')){ 
			callback( new Error( String.format( CHECK_MSG.PIN_NOT_VIRTUAL, pinnumber ) ) );return false;
		}
		callback(null);
		return true;
	}
	catch(err){
		callback( new Error('Check Virtual Write '+ err.message) );
		return false
	}
}
function checkVirtualRead(pinnumber){	
	try{
		if( typeof(pinnumber) == 'undefined'){
			callback( new Error( CHECK_MSG.PIN_UNDEFINED ) );return false;
		}
		if( !pinnumber.toLowerCase().startsWith('v')){ 
			callback( new Error( String.format( CHECK_MSG.PIN_NOT_VIRTUAL, pinnumber ) ) );return false;
		}
		callback(null);
		return true;
	}
	catch(err){
		callback( new Error('Check Virtual Read '+ err.message) );
		return false
	}
}
/*** System Functions ***/
/*** push write command for bridge inside a buffer ***/
/*
function pushWriteRequest(cmd){
	if(writeBuffer.length < BUFFER_SIZE){
		writeBuffer.push(cmd);
	}
}*/
/*** get the command from the buffer and send it to the bridge ***/

//function sendWriteRequest(){
//	if(/*typeof(socket) != 'undefined' && */writeBuffer.length > 0){
//		//socket.write(writeBuffer.shift(), ENCODING);
//		cmd = JSON.parse(writeBuffer.shift());
//		gpio_write_value(layout2[ cmd.command[0].pin ], cmd.command[0].value );
//	}
//}