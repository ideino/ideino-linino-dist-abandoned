/***
 * file: board.js
 * version: 0.6.0
 * author: https://github.com/quasto
  ***/

/*** import ***/
var	layouts = require('./utils/layout'),
	registers = require('./utils/register'),
	utils = require('./utils/utils'),
	path = require('path');
	EventEmitter = require('events').EventEmitter,
	exec = require('child_process').exec,
	Gpio = require('./lib/gpio').Gpio,
	Adc = require('./lib/adc').Adc,
	Pwm = require('./lib/pwm').Pwm;
	
var	pinReg = {},		//list for storing the mode of every used pin of the board
	logger,				//winston logger
	layout,
	register,	
	event = new EventEmitter();
	
/*** constants ***/	
var	CHECK_MSG = {	PIN_UNDEFINED : 	"The specified pin is undefined!",
					PIN_NOT_DIGITAL: 	"The specified pin [{0}] is not a Digital pin",
					PIN_NOT_ANALOG: 	"The specified pin [{0}] is not an Analog pin",
					PIN_NOT_VIRTUAL: 	"The specified pin [{0}] is not a Virtual pin",
					PIN_NOT_LAYOUT:		"The specified pin [{0}] is not defined in the board layout!",
					PIN_NOT_DEFINED:	"The specified pin [{0}] is not already defined! You must first, call pinMode!",
					MODE_NOT_VALID: 	"The specified mode [{0}] for pin [{1}] is not valid.",
					MODE_UNDEFINED : 	"The specified mode for pin [{0}] is undefined!"
				};
	/*,
	MCUIO_GPIO = '/sys/class/gpio/',
	MCUIO_GPIO_E = '/sys/class/gpio/',
	MCUIO_ADC = '/sys/class/mcuio_adc/',
	MCUIO_ADC_E = '/sys/devices/mcuio/0:0.0/adc/enable';
	*/
				
module.exports = Board;

/*** constructor ***/
function Board(options) {

	//load the default options from config file
	var file_options = require('./config');
	
	//user can specifies overwrite options in the costructor
	this._options = utils.mergeRecursive(file_options, options);
	//file_options.merge(options);
	//this._options = file_options;

	this._bridge = {
			bridge : 'bridge-firmata.py',
			stop : 'bridge-stop',
			bridge_exe : path.join(__dirname,'ext','bridge-firmata.py'),
			stop_exe : path.join(__dirname,'ext','bridge-stop'),
			loglevel : 'info', 		//error, warn, info, debug //this._options.logger.level (prima di mettere questo, devo togliere molti log dal bridge, altrimenti in debug impazzisce per i troppi log //
			loghandler : this._options.logger.handler, 	//file, console, all (file + console)
			layout : this._options.layout,				//arduino_yun, linino_one
			layoutfile : path.join(__dirname,'utils','layout.json'),	//layout file
			resolution : this._options.bridge.resolution,
			//serial: this._options.bridge.serial,
			sampling : this._options.bridge.sampling			
	};
	
	layout = layouts[this._options.layout];
	register = registers[this._options.layout];
	//setting the logger;
	logger = utils.getLogger(this._options.logger);
	logger.debug(file_options);
	
	/*** Board attributes ***/
	Board.prototype.pin = layout;
	Board.prototype.LOW = utils.LOW;
	Board.prototype.HIGH = utils.HIGH;
	Board.prototype.MODES = utils.MODES; 
	Board.prototype.logger = logger;
	
	event.setMaxListeners(0);
}

/*** PUBLIC ***/  
/*** Board functions ***/
Board.prototype.connect = function(callback){
	logger.info("Connecting to the Board "+ this._options.layout +"...");
	var that = this;
	that.blink(75, 1500, 'D13');
	logger.info("Board Connection Success");
	callback();

}


Board.prototype.blink = function(){
	var that = this;
	// retrieve arguments as array
    var args = [];
    var delay, duration;
	for (var i = 0; i < arguments.length; i++) {
        args.push(arguments[i]);
    }
	var delay, led, duration;
	//check loglevel parameters
	if (args.length > 0) delay = args.shift(); else throw new Error("specify delay parameter.");
    if (args.length > 0) duration = args.shift(); else duration = 0;
	if (args.length > 0) led = args.shift(); else led = layout.digital.D13;

	if ( !isNaN(delay) ){
		if( typeof(duration) != 'undefined'  && !isNaN(duration) ){
			that.pinMode(led, utils.MODES.OUTPUT);
			var t = utils.LOW,
			interval = setInterval( function(){
				that.digitalWrite(led, t );
				t = t == utils.LOW ? utils.HIGH : utils.LOW;
			}, delay);
			
			if(duration > 0 ){
				setTimeout(function(){
					clearInterval(interval);
					that.digitalWrite(led, utils.LOW);
				},duration);
			}
		}
		else{
			throw new Error("duration is not a number."); 
		}
	}else{
		throw new Error("delay is not a number."); 
	}

	
}
Board.prototype.pinMode = function(pin, mode) {
	try {
		checkPinMode(pin,mode,function(err){
			if(err){
				throw err;
			}
			else{
				switch(mode.toLowerCase()) {
					case 'input':
						register[pin].PIN = new Gpio(register[pin].NUM, 
													register[pin].MAP,
													'in',
													'both');
						pinReg[pin] = mode; //TODO modificare il check pin mode per gestire diversamente il pinReg direttamente con layout2
						break;
					case 'output':
						register[pin].PIN = new Gpio(register[pin].NUM, 
													register[pin].MAP,
													'out');
						pinReg[pin] = mode;//TODO modificare il check pin mode per gestire diversamente il pinReg direttamente con layout2
						break;
					case 'pwm':
						register[pin].PIN = new Pwm(register[pin].NUM, 
													register[pin].MAP);
						pinReg[pin] = mode;//TODO modificare il check pin mode per gestire diversamente il pinReg direttamente con layout2
						break;
					case 'servo':
						//TODO
						break;
				}
			}
		});
	}
	catch(err){
		logger.error("BOARD PIN MODE ERROR - " + err.message);
		exec("sh " + this._bridge.stop_exe + " " + this._bridge.bridge, function (error, stdout, stderr) {
			process.exit(1);
		});		
	}
}
Board.prototype.digitalWrite = function(pin, value) {
    try {
		process.nextTick(function(){
			checkDigitalWrite(pin, function(err){
				if(err){
					logger.error(err.message);
				}else{
					register[pin].PIN.writeSync(value);
				}
			});		
		});
	}
	catch(err){
		logger.error("BOARD DIGITAL WRITE ERROR - " + err.message);
	}
}
Board.prototype.digitalRead = function(pin, callback) {
	try {
		process.nextTick(function(){
			checkDigitalRead(pin,function(err){
				if(err){
					logger.error(err.message);
				}
				else{
					if (typeof callback === 'function')
						register[pin].PIN.watch(function(err, val){
							if(err) logger.error(err.message);
							else callback( { value : val } );
						});
					//TODO read sync
					//else {console.log(register[pin].PIN.readSync());
					//	return register[pin].PIN.readSync();
					//	}
				}
			});
		});
	}
	catch(err){
		logger.error("BOARD DIGITAL READ ERROR - " + err.message);
	}  
}
Board.prototype.analogWrite = function(pin, value) {
    try {
		process.nextTick(function(){
			checkAnalogWrite(pin, function(err){
				if(err){
					logger.error(err.message);
				}else{
					if(value>=255) value = 255;
					if(value<=0) value = 0;
					register[pin].PIN.writeSync(value);	
				}
			});
		});
	}
	catch(err){
		logger.error("BOARD ANALOG WRITE ERROR - " + err.message);
	}
}
Board.prototype.analogRead = function(pin, callback) {
    try {var that = this;
		process.nextTick(function(){
			checkAnalogRead(pin,function(err){
				if(err){
					logger.error(err.message);
				}
				else{
					if(typeof(register[pin].PIN) == 'undefined' || typeof(register[pin].PIN) == {} ){
						register[pin].PIN = new Adc(register[pin].NUM, 
													register[pin].MAP,
													that._options.bridge); //TODO riassettare i parametri
					}
					register[pin].PIN.watch(function(err, val){
						if(err) logger.error(err.message);
						else callback( { value : val } );
					}); 
				}
			});
		});
	}
	catch(err){
		logger.error("BOARD ANALOG READ ERROR - " + err.message);
	}
}
Board.prototype.servoWrite = function(pin, angle){
    try {
		process.nextTick(function(){
			checkServoWrite(pin,function(err){
				if(err){
					logger.error(err.message);
				}
				else{
					var cmd = JSON.stringify({command:[{cmd: 'write', pin: pin, value: angle}]});
					//socket.write(cmd,'utf8'); //when connection is ok, emit the request
					pushWriteRequest(cmd);
				}
			});
		});
	}
	catch(err){
		logger.error("BOARD SERVO WRITE ERROR - " + err.message);
	}
}
/*** Virtual Board functions ***/ 
Board.prototype.virtualWrite = function(virtualpin, value){
	try {
		checkVirtualWrite(pin,function(err){
			if(err){
				logger.error(err.message);
			}
			else{
				var cmd = JSON.stringify({ command:[ {cmd: 'virtualwrite', pin: virtualpin, value: value } ]});
				pushWriteRequest(cmd);
			}
		});
				
	}
	catch(err){
		logger.error(err);
	}
}
Board.prototype.virtualRead = function(virtualpin, calback){
	try {
		checkVirtualRead(pin,function(err){
			if(err){
				logger.error(err.message);
			}
			else{
				var cmd = JSON.stringify({command:[{cmd: 'vread', pin: virtualpin}]});
				socket.write(cmd,ENCODING,readback(pin, callback)); //when connection is ok, emit the request
			}
		});
	}
	catch(err){
		logger.error(err.message);
	} 
}

/*** Check functions ***/
function checkPinMode(pinnumber, mode, callback){
	try{	
		if( typeof(pinnumber) == 'undefined'){
			callback( new Error(CHECK_MSG.PIN_UNDEFINED) );return false;
		}
		if( !pinnumber.toLowerCase().startsWith('d') && !pinnumber.toLowerCase().startsWith('p')){ 
			callback( new Error(String.format(CHECK_MSG.PIN_NOT_DIGITAL,pinnumber)) );return false
		}
		if( !utils.contains(layout.digital, pinnumber) && !utils.contains(layout.pwm, pinnumber)){
			callback( new Error(String.format(CHECK_MSG.PIN_NOT_LAYOUT,pinnumber)) );return false;
		}
		if( typeof(mode) == 'undefined'){
			callback(new Error(String.format(CHECK_MSG.MODE_UNDEFINED,pinnumber)) );return false;
		}
		if(	mode.toLowerCase() != utils.MODES.OUTPUT.toLowerCase()	&& 
			mode.toLowerCase() != utils.MODES.INPUT.toLowerCase() 	&&
			mode.toLowerCase() != utils.MODES.PWM.toLowerCase() 	&& 
			mode.toLowerCase() != utils.MODES.SERVO.toLowerCase()	){
			callback(new Error(String.format(CHECK_MSG.MODE_NOT_VALID, mode, pinnumber) + " Allowed modes are: "+ utils.MODES.OUTPUT +", "+ utils.MODES.INPUT + ", "+ utils.MODES.PWM + ", "+ utils.MODES.SERVO ));return false;
		}
		
		callback(null);
		return true;
	}
	catch(err){
		callback( new Error('Check Pin Mode '+ err.message) );
		return false
	}
}
function checkDigitalWrite(pinnumber, callback){	
	try{
		if( typeof(pinnumber) == 'undefined'){
			callback( new Error( CHECK_MSG.PIN_UNDEFINED ) );return false;
		}
		if( !pinnumber.toLowerCase().startsWith('d')){ 
			callback( new Error( String.format(CHECK_MSG.PIN_NOT_DIGITAL, pinnumber) ) );return false;
		}
		if(typeof(pinReg[pinnumber]) == 'undefined'){
			callback( new Error( String.format(CHECK_MSG.PIN_NOT_DEFINED, pinnumber) ) );return false;
		}
		if( !utils.contains(layout.digital, pinnumber) ){
			callback( new Error(String.format(CHECK_MSG.PIN_NOT_LAYOUT, pinnumber) ) );return false;
		}
		if(pinReg[pinnumber].toLowerCase() != utils.MODES.OUTPUT.toLowerCase() ){
			callback(new Error( String.format(CHECK_MSG.MODE_NOT_VALID, pinReg[pinnumber].toLowerCase(), pinnumber) + " Allowed modes are: "+ utils.MODES.OUTPUT));return false;
		}
		
		callback(null);
		return true;
	}
	catch(err){
		callback( new Error('Check Digital Write '+ err.message) );
		return false
	}
}
function checkDigitalRead(pinnumber, callback){
	try{
		if( typeof(pinnumber) == 'undefined'){
			callback( new Error( CHECK_MSG.PIN_UNDEFINED ) );return false;
		}
		if( !pinnumber.toLowerCase().startsWith('d')){ 
			callback( new Error( String.format(CHECK_MSG.PIN_NOT_DIGITAL, pinnumber) ) );return false;
		}
		if(typeof(pinReg[pinnumber]) == 'undefined'){
			callback( new Error( String.format(CHECK_MSG.PIN_NOT_DEFINED, pinnumber) ) );return false;
		}
		if( !utils.contains(layout.digital, pinnumber) ){
			callback( new Error(String.format(CHECK_MSG.PIN_NOT_LAYOUT, pinnumber) ) );return false;
		}
		if(	pinReg[pinnumber].toLowerCase() != utils.MODES.OUTPUT.toLowerCase()	&& 
			pinReg[pinnumber].toLowerCase() != utils.MODES.INPUT.toLowerCase() 	&&
			pinReg[pinnumber].toLowerCase() != utils.MODES.PWM.toLowerCase() ){
			callback(new Error(String.format(CHECK_MSG.MODE_NOT_VALID, pinReg[pinnumber].toLowerCase(), pinnumber) + " Allowed modes are: "+ utils.MODES.OUTPUT +", "+ utils.MODES.INPUT + ", "+ utils.MODES.PWM ));return false;
		}
		
		callback(null);
		return true;
	}
	catch(err){
		callback( new Error('Check Digital Read '+ err.message) );
		return false
	}
}
function checkAnalogWrite(pinnumber,callback){	
	try{
		if( typeof(pinnumber) == 'undefined'){
			callback( new Error( CHECK_MSG.PIN_UNDEFINED ) );return false;
		}
		if( !pinnumber.toLowerCase().startsWith('d') && !pinnumber.toLowerCase().startsWith('p')){ 
			callback( new Error( String.format(CHECK_MSG.PIN_NOT_DIGITAL, pinnumber) ) );return false;
		}
		if(typeof(pinReg[pinnumber]) == 'undefined'){
			callback( new Error( String.format(CHECK_MSG.PIN_NOT_DEFINED, pinnumber) ) );return false;
		}
		if( !utils.contains(layout.pwm, pinnumber) ){
			callback( new Error(String.format(CHECK_MSG.PIN_NOT_LAYOUT, pinnumber) ) );return false;
		}
		if(pinReg[pinnumber].toLowerCase() != utils.MODES.PWM.toLowerCase() ){
			callback(new Error( String.format(CHECK_MSG.MODE_NOT_VALID, pinReg[pinnumber].toLowerCase(), pinnumber) + " Allowed modes are: "+ utils.MODES.PWM));return false;
		}
		
		callback(null);
		return true;
	}
	catch(err){
		callback( new Error('Check Analog Write '+ err.message) );
		return false
	}
}
function checkAnalogRead(pinnumber,callback){
	try{
		if( typeof(pinnumber) == 'undefined'){
			callback( new Error( CHECK_MSG.PIN_UNDEFINED ) );return false;
		}
		if( !pinnumber.toLowerCase().startsWith('a') && !pinnumber.toLowerCase().startsWith('p')){ 
			callback( new Error( String.format( CHECK_MSG.PIN_NOT_ANALOG, pinnumber ) ) );return false;
		}
		/* analog pin are in input mode (default), non verifico il pin mode
		if(typeof(pinReg[pinnumber]) == 'undefined'){
			callback( new Error( String.format(CHECK_MSG.PIN_NOT_DEFINED, pinnumber) ) );return false;
		}
		*/
		if( !utils.contains(layout.analog, pinnumber) && !utils.contains(layout.pwm, pinnumber)){
			callback( new Error(String.format(CHECK_MSG.PIN_NOT_LAYOUT, pinnumber) ) );return false;
		}
		callback(null);
		return true;
	}
	catch(err){
		callback( new Error('Check Analog Read '+ err.message) );
		return false
	}
}
function checkServoWrite(pinnumber,callback){	
	try{
		if( typeof(pinnumber) == 'undefined'){
			callback( new Error( CHECK_MSG.PIN_UNDEFINED ) );return false;
		}
		if( !pinnumber.toLowerCase().startsWith('d')){ 
			callback( new Error( String.format( CHECK_MSG.PIN_NOT_DIGITAL, pinnumber ) ) );return false;
		}
		if(typeof(pinReg[pinnumber]) == 'undefined'){
			callback( new Error( String.format(CHECK_MSG.PIN_NOT_DEFINED, pinnumber) ) );return false;
		}
		if( !utils.contains(layout.servo, pinnumber) ){
			callback( new Error(String.format(CHECK_MSG.PIN_NOT_LAYOUT, pinnumber) ) );return false;
		}
		if(pinReg[pinnumber].toLowerCase() != utils.MODES.SERVO.toLowerCase() ){
			callback(new Error( String.format(CHECK_MSG.MODE_NOT_VALID, pinReg[pinnumber].toLowerCase(), pinnumber) + " Allowed modes are: "+ utils.MODES.SERVO));return false;
		}
		
		callback(null);
		return true;
	}
	catch(err){
		callback( new Error('Check Servo Write '+ err.message) );
		return false
	}
}
function checkVirtualWrite(pinnumber, callback){	
	try{
		if( typeof(pinnumber) == 'undefined'){
			callback( new Error( CHECK_MSG.PIN_UNDEFINED ) );return false;
		}
		if( !pinnumber.toLowerCase().startsWith('v')){ 
			callback( new Error( String.format( CHECK_MSG.PIN_NOT_VIRTUAL, pinnumber ) ) );return false;
		}
		callback(null);
		return true;
	}
	catch(err){
		callback( new Error('Check Virtual Write '+ err.message) );
		return false
	}
}
function checkVirtualRead(pinnumber){	
	try{
		if( typeof(pinnumber) == 'undefined'){
			callback( new Error( CHECK_MSG.PIN_UNDEFINED ) );return false;
		}
		if( !pinnumber.toLowerCase().startsWith('v')){ 
			callback( new Error( String.format( CHECK_MSG.PIN_NOT_VIRTUAL, pinnumber ) ) );return false;
		}
		callback(null);
		return true;
	}
	catch(err){
		callback( new Error('Check Virtual Read '+ err.message) );
		return false
	}
}
